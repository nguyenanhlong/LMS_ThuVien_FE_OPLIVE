export const API_BASE = 'http://localhost:3000';

function getToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('access_token');
}

function getRefreshToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('refresh_token');
}

function setTokens(access: string, refresh?: string) {
  localStorage.setItem('access_token', access);
  if (refresh) localStorage.setItem('refresh_token', refresh);
}

function clearTokens() {
  localStorage.removeItem('access_token');
  localStorage.removeItem('refresh_token');
}

async function refreshAccessToken() {
  const refresh = getRefreshToken();
  if (!refresh) return null;
  try {
    const res = await fetch(`${API_BASE}/graphql`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: `
          mutation RefreshToken($input: RefreshInput!) {
            refreshToken(input: $input) {
              access_token
              refresh_token
            }
          }
        `,
        variables: {
          input: {
            refresh_token: refresh
          }
        }
      })
    });
    if (!res.ok) { clearTokens(); return null; }
    const json = await res.json();
    if (json.errors) { clearTokens(); return null; }
    const token = json.data?.refreshToken?.access_token;
    const newRefresh = json.data?.refreshToken?.refresh_token;
    if (token) setTokens(token, newRefresh);
    return token;
  } catch { clearTokens(); return null; }
}

export async function graphqlQuery<T = any>(query: string, variables?: any, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  let res = await fetch(`${API_BASE}/graphql`, {
    method: 'POST',
    body: JSON.stringify({ query, variables }),
    headers,
    ...options,
  });

  let json = await res.json();

  const isUnauthorized = json.errors?.some((err: any) => err.message === 'Unauthorized');

  if ((res.status === 401 || isUnauthorized) && getRefreshToken()) {
    const newToken = await refreshAccessToken();
    if (newToken) {
      headers['Authorization'] = `Bearer ${newToken}`;
      res = await fetch(`${API_BASE}/graphql`, {
        method: 'POST',
        body: JSON.stringify({ query, variables }),
        headers,
        ...options,
      });
      json = await res.json();
    }
  }

  if (json.errors) {
    const msg = json.errors[0].message || 'GraphQL Error';
    throw new Error(msg);
  }

  return json.data as T;
}

export async function loginApi(username: string, password: string) {
  const res = await fetch(`${API_BASE}/graphql`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      query: `
        mutation Login($input: LoginInput!) {
          login(input: $input) {
            access_token
            refresh_token
          }
        }
      `,
      variables: {
        input: { username, password }
      }
    }),
  });
  const json = await res.json();
  if (json.errors) {
    const msg = json.errors[0].message || 'Login failed';
    throw new Error(msg);
  }
  const tokens = json.data?.login;
  if (tokens?.access_token) {
    setTokens(tokens.access_token, tokens.refresh_token);
  }
  return tokens;
}

export async function registerApi(data: { username: string; full_name: string; email: string; password: string }) {
  return graphqlQuery(`
    mutation Register($input: RegisterInput!) {
      register(input: $input) {
        id
        username
        email
        full_name
        is_active
      }
    }
  `, {
    input: {
      username: data.username,
      full_name: data.full_name,
      email: data.email,
      password: data.password
    }
  }).then(r => r.register);
}

export { getToken, clearTokens };

const LOAN_FIELDS = `
  id
  loan_date
  status
  cancelled_reason
  total_deposit
  total_rental_fee
  total_amount
  total_fine
  total_lost_fee
  total_initial_payment
  total_deposit_refund
  total_extra_payment
  borrower {
    user_id
    full_name
    email
  }
  books {
    loan_detail_id
    book_id
    title
    author
    image_url
    quantity
    borrow_days
    due_date
    return_date
    status
    deposit_amount
    rental_fee
    fine_amount
    lost_quantity
    lost_fee
    deposit_refund_amount
    extra_payment_amount
  }
`;

const BOOK_FIELDS = `
  id
  title
  isbn
  author
  image_url
  publisher
  publisher_year
  description
  total_quantity
  borrowed_quantity
  max_borrow_days
  deposit_amount
  fine_per_day
  replacement_cost
  fee_per_day
  fee_per_week
  fee_per_month
  is_active
  sub_category_id
  sub_category {
    id
    name
  }
`;

export async function getLoansApi(params?: { status?: string; pageSize?: number; user_id?: number }) {
  return graphqlQuery<any>(`
    query GetLoans($query: GetLoansInput) {
      loans(query: $query) {
        items ${LOAN_FIELDS}
      }
    }
  `, {
    query: {
      ...(params?.status ? { status: params.status } : {}),
      ...(params?.user_id ? { user_id: params.user_id } : {}),
      pageSize: params?.pageSize ?? 100,
    }
  }).then(r => r.loans);
}

export async function getLoanByIdApi(id: string | number) {
  return graphqlQuery<any>(`
    query GetLoan($id: ID!) {
      loan(id: $id) ${LOAN_FIELDS}
    }
  `, { id: String(id) }).then(r => r.loan);
}

export async function confirmLoanApi(id: string | number) {
  return graphqlQuery(`
    mutation ConfirmLoan($id: ID!) {
      confirmLoan(id: $id)
    }
  `, { id: String(id) });
}

export async function borrowingLoanApi(id: string | number) {
  return graphqlQuery(`
    mutation PayAndBorrow($id: ID!) {
      payAndBorrow(id: $id)
    }
  `, { id: String(id) });
}

export async function returnLoanDetailApi(detailId: string | number, lost_quantity = 0) {
  return graphqlQuery(`
    mutation ReturnLoanDetail($detailId: ID!, $lostQuantity: Int!) {
      returnLoanDetail(detailId: $detailId, lostQuantity: $lostQuantity)
    }
  `, { detailId: String(detailId), lostQuantity: lost_quantity });
}

export async function cancelLoanApi(id: string | number, cancelled_reason: string) {
  return graphqlQuery(`
    mutation CancelLoan($id: ID!, $reason: String!) {
      cancelLoan(id: $id, reason: $reason)
    }
  `, { id: String(id), reason: cancelled_reason });
}

export async function getBooksApi(params?: { keyword?: string; sub_category_id?: number; author?: string; is_active?: boolean; pageSize?: number }) {
  return graphqlQuery<any>(`
    query GetBooks($query: GetBooksInput) {
      books(query: $query) {
        items ${BOOK_FIELDS}
      }
    }
  `, {
    query: {
      ...(params?.keyword ? { keyword: params.keyword } : {}),
      ...(params?.sub_category_id ? { sub_category_id: params.sub_category_id } : {}),
      ...(params?.author ? { author: params.author } : {}),
      ...(params?.is_active !== undefined ? { is_active: params.is_active } : {}),
      pageSize: params?.pageSize ?? 100,
    }
  }).then(r => r.books);
}

export async function createBookApi(data: any) {
  return graphqlQuery(`
    mutation CreateBook($input: CreateBookInput!) {
      createBook(input: $input) {
        id
      }
    }
  `, { input: data });
}

export async function updateBookApi(id: string | number, data: any) {
  return graphqlQuery(`
    mutation UpdateBook($id: ID!, $input: UpdateBookInput!) {
      updateBook(id: $id, input: $input) {
        id
      }
    }
  `, { id: String(id), input: data });
}

export async function deleteBookApi(id: string | number) {
  return graphqlQuery(`
    mutation DeleteBook($id: ID!) {
      deleteBook(id: $id)
    }
  `, { id: String(id) });
}

export async function getCategoriesApi() {
  return graphqlQuery<any>(`
    query GetCategories {
      categories {
        id
        name
      }
    }
  `).then(r => r.categories);
}

export async function getSubCategoriesApi(category_id?: number) {
  return graphqlQuery<any>(`
    query GetSubCategories($categoryId: Int) {
      subCategories(categoryId: $categoryId) {
        id
        category_id
        name
      }
    }
  `, { categoryId: category_id }).then(r => r.subCategories);
}
